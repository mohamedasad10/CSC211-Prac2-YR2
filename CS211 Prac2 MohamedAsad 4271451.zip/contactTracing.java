/* Name:           Mohamed Asad Bandarkar
   Student Number: 4271451
   Due Date:       05/03/2023
 */
import java.util.Scanner;

public class contactTracing {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the number of babies in the creche: ");
        int numBabies = scanner.nextInt();

        //creating an array for arrival and departure times
        double[] arrival = new double[numBabies];
        double[] depart = new double[numBabies];

        for (int i = 0; i < numBabies; i++) {
            System.out.println("Give the times of arrival (i) and departure (j): ");
            arrival[i] = scanner.nextDouble();          //storing the times into array arrival
            depart[i] = scanner.nextDouble();           ///storing the times into array depart
        }

        int count = 0;

        for (int i = 0; i < numBabies; i++) {
            for (int j = i + 1; j < numBabies; j++) {
                if ((arrival[i] >= arrival[j] && arrival[i] <= depart[j]) ||
                        (arrival[j] >= arrival[i] && arrival[j] <= depart[i])) {
                    count++;
                }
            }
        }

        System.out.println("Number of distinct pairs of babies at the creche simultaneously: " + count);
    }
}

